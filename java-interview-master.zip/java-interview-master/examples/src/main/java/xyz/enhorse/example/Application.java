package xyz.enhorse.example;

public class Application {

    public static void main(String[] args) {
        System.out.println("Examples for Java Developer interview preparation materials!");
    }
}
